'use strict';
const fs = require('node:fs');
const path = require('node:path');
const names = ['utils', 'http', 'catalog', 'player', 'index'];
const banner = '/* DiziBOX TV for Nuvio v1.0.0\n' + fs.readFileSync(path.join(__dirname, 'LICENSE'), 'utf8') + '\n*/\n';
const modules = names.map(name => {
  const source = fs.readFileSync(path.join(__dirname, 'src', name + '.js'), 'utf8');
  if (/\b(?:async\s+function|await\s|eval\s*\(|new\s+Function\b)/.test(source)) throw new Error('Unsupported runtime syntax in ' + name);
  return JSON.stringify(name) + ': function(module, exports, require) {\n' + source.replace(/require\(['"]\.\/([a-z]+)['"]\)/g, 'require("$1")') + '\n}';
});
const output = banner + '(function () {\nvar externalRequire = typeof require === "function" ? require : null;\nvar modules = {\n' + modules.join(',\n') + '\n};\nvar cache = {};\nfunction load(id) {\n if (cache[id]) return cache[id].exports;\n if (!modules[id]) { if (id === "crypto-js" && externalRequire) return externalRequire(id); throw new Error("Runtime module unavailable: " + id); }\n var local = { exports: {} }; cache[id] = local;\n modules[id](local, local.exports, load);\n return local.exports;\n}\nmodule.exports = load("index");\n}());\n';
fs.writeFileSync(path.join(__dirname, 'dizibox.js'), output);
console.log('Built dizibox.js (' + Buffer.byteLength(output) + ' bytes)');
