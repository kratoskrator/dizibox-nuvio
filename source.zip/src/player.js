'use strict';
var u = require('./utils');
var http = require('./http');
var manifest = require('./media');
var cryptoCache;

function httpsUrl(value, base) {
  var url = u.absolute(value, base);
  return /^https:\/\/[a-z0-9.-]+(?::\d+)?(?:[/?#]|$)/i.test(url) && !/[\x00-\x20\x7f<>"'\\]/.test(url) ? url : '';
}

// Read literal strings only. Expressions and downloaded scripts are never run.
function literal(source, start) {
  var quote = source.charAt(start);
  if (quote !== '"' && quote !== "'") return null;
  var out = '';
  var i = start + 1;
  for (; i < source.length; i++) {
    var c = source.charAt(i);
    if (c === quote) return { value: out, end: i + 1 };
    if (c !== '\\') { out += c; continue; }
    c = source.charAt(++i);
    if (c === 'u' || c === 'x') {
      var size = c === 'u' ? 4 : 2;
      var code = source.slice(i + 1, i + 1 + size);
      if (!new RegExp('^[0-9a-f]{' + size + '}$', 'i').test(code)) return null;
      out += String.fromCharCode(parseInt(code, 16));
      i += size;
    } else if (c === '\n') { /* line continuation */ }
    else if (c === '\r') { if (source.charAt(i + 1) === '\n') i++; }
    else out += { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', v: '\v' }[c] || c;
    if (out.length > 512 * 1024) return null;
  }
  return null;
}

function cryptoLibrary() {
  if (cryptoCache) return cryptoCache;
  if (typeof globalThis !== 'undefined' && globalThis.CryptoJS) cryptoCache = globalThis.CryptoJS;
  else {
    try { cryptoCache = require('crypto-js'); } catch (ignored) {}
  }
  if (!cryptoCache || !cryptoCache.AES || !cryptoCache.enc || !cryptoCache.enc.Utf8) throw new Error('Nuvio CryptoJS support is required for this player');
  return cryptoCache;
}

function decode(html) {
  var match = /\bCryptoJS\s*\.\s*AES\s*\.\s*decrypt\s*\(\s*/.exec(html);
  if (!match) return html;
  var encrypted = literal(html, match.index + match[0].length);
  if (!encrypted || !/^U2FsdGVkX1[A-Za-z0-9+/=]+$/.test(encrypted.value) || encrypted.value.length > 400 * 1024) return '';
  var tail = /^\s*,\s*/.exec(html.slice(encrypted.end));
  if (!tail) return '';
  var password = literal(html, encrypted.end + tail[0].length);
  if (!password || password.value.length > 256 || !/^\s*\)/.test(html.slice(password.end))) return '';
  var crypto = cryptoLibrary();
  try {
    var plain = crypto.AES.decrypt(encrypted.value, password.value).toString(crypto.enc.Utf8);
    return plain.length <= 1024 * 1024 ? plain : '';
  } catch (ignored) { return ''; }
}

function objectRanges(source) {
  var stack = [];
  var ranges = [];
  for (var i = 0; i < source.length; i++) {
    var c = source.charAt(i);
    if (c === '"' || c === "'") {
      var str = literal(source, i);
      if (!str) break;
      i = str.end - 1;
    } else if (source.slice(i, i + 2) === '//') {
      var nl = source.indexOf('\n', i + 2);
      i = nl < 0 ? source.length : nl;
    } else if (source.slice(i, i + 2) === '/*') {
      var close = source.indexOf('*/', i + 2);
      i = close < 0 ? source.length : close + 1;
    } else if (c === '{') stack.push(i);
    else if (c === '}' && stack.length) ranges.push({ start: stack.pop(), end: i + 1 });
  }
  return ranges;
}

function property(source, name) {
  var re = new RegExp('(?:[,{]\\s*)(?:["\\\x27]?' + name + '["\\\x27]?)\\s*:\\s*', 'i');
  var match = re.exec(source);
  if (!match) return '';
  var value = literal(source, match.index + match[0].length);
  return value && /^\s*[,}]/.test(source.slice(value.end)) ? value.value : '';
}

function configurations(html) {
  var result = [];
  var re = /\bjwplayer\s*\([^)]{0,160}\)\s*\.\s*setup\s*\(\s*/g;
  var match;
  while ((match = re.exec(html)) && result.length < 3) {
    var start = re.lastIndex;
    if (html.charAt(start) !== '{') continue;
    var rest = html.slice(start);
    var ranges = objectRanges(rest);
    for (var i = ranges.length - 1; i >= 0; i--) {
      if (ranges[i].start === 0) { result.push(rest.slice(0, ranges[i].end)); break; }
    }
  }
  return result;
}

function playbackHeaders(pageURL) {
  return { Referer: pageURL, Origin: u.origin(pageURL), 'User-Agent': http.USER_AGENT };
}

function media(html, pageURL) {
  var configs = configurations(html);
  var streams = [];
  var subtitles = [];
  configs.forEach(function (config) {
    var ranges = objectRanges(config);
    var re = /(?:[,{]\s*)(?:["']?file["']?)\s*:\s*/g;
    var match;
    while ((match = re.exec(config)) && streams.length + subtitles.length < 16) {
      var value = literal(config, re.lastIndex);
      if (!value || !/^\s*[,}]/.test(config.slice(value.end))) continue;
      var url = httpsUrl(value.value, pageURL);
      if (!url) continue;
      var parent = config;
      var best = config.length + 1;
      ranges.forEach(function (range) {
        if (range.start <= match.index && range.end >= value.end && range.end - range.start < best) {
          best = range.end - range.start;
          parent = config.slice(range.start, range.end);
        }
      });
      var kind = property(parent, 'kind').toLowerCase();
      var label = property(parent, 'label');
      var type = property(parent, 'type').toLowerCase();
      if (kind === 'captions' || kind === 'subtitles' || (!kind && /\.(?:vtt|srt)(?:[?#]|$)/i.test(url))) {
        subtitles.push({ id: 'dizibox-' + subtitles.length, url: url, language: property(parent, 'srclang') || (/t[uü]rk/i.test(label) ? 'tr' : 'und'), name: label || 'Subtitle', headers: playbackHeaders(pageURL) });
      } else if (/mpegurl|^hls$/.test(type) || /\.m3u8(?:[?#]|$)|\/embed\/sheila\//i.test(url)) {
        streams.push({ url: url, quality: 'Auto', type: 'hls', headers: playbackHeaders(pageURL), subtitles: [] });
      }
    }
  });
  var sourceRe = /<(?:source|video)\b[^>]*>/gi;
  var tag;
  while ((tag = sourceRe.exec(html)) && streams.length < 8) {
    var src = httpsUrl(u.attr(tag[0], 'src'), pageURL);
    if (src && (/mpegurl/i.test(u.attr(tag[0], 'type')) || /\.m3u8(?:[?#]|$)/i.test(src))) streams.push({ url: src, quality: 'Auto', type: 'hls', headers: playbackHeaders(pageURL), subtitles: [] });
  }
  return streams.filter(function (stream, index, all) {
    stream.subtitles = subtitles.slice();
    return all.map(function (s) { return s.url; }).indexOf(stream.url) === index;
  });
}

function frameUrls(html, pageURL, siteOrigin) {
  var list = [];
  var re = /<iframe\b[^>]*>/gi;
  var tag;
  while ((tag = re.exec(html)) && list.length < 4) {
    var url = httpsUrl(u.attr(tag[0], 'src') || u.attr(tag[0], 'data-src'), pageURL);
    var root = u.origin(url).toLowerCase();
    if (!url || /\/cdn-cgi\//i.test(url)) continue;
    if (root !== siteOrigin && !/^https:\/\/(?:[a-z0-9-]+\.)*molystream\.(?:org|net)$/i.test(root)) continue;
    if (!/(?:\/(?:player\/)?(?:[a-z0-9_-]+\/)?(?:king|moly|haydi|player)\.php(?:\?|$)|\/embed\/)/i.test(url)) continue;
    if (list.indexOf(url) < 0) list.push(url);
  }
  return list;
}

function resolve(html, pageURL, options) {
  options = options || {};
  var request = options.request || http.request;
  var visited = {};
  var count = 0;
  var siteOrigin = (options.siteOrigin || u.origin(pageURL)).toLowerCase();
  var maxRequests = Math.min(8, options.maxRequests || 6);
  var maxDepth = Math.min(4, options.maxDepth || 4);
  function get(url, referer) {
    if (++count > maxRequests) return Promise.resolve('');
    return request(url, { referer: referer, origin: u.origin(referer), timeout: options.timeout || 10000 });
  }
  function verified(stream) {
    return get(stream.url, stream.headers.Referer).then(function (body) {
      var checked = manifest.hls(body);
      if (checked) { stream.quality = checked.quality || 'Auto'; return stream; }
      var value = String(body).trim();
      var target = /^https:\/\//i.test(value) ? httpsUrl(value, stream.url) : '';
      if (!target || target === stream.url) return null;
      return get(target, stream.headers.Referer).then(function (playlist) {
        var checked = manifest.hls(playlist);
        if (!checked) return null;
        stream.url = target;
        stream.quality = checked.quality || 'Auto';
        return stream;
      });
    });
  }
  function walk(body, url, depth) {
    if (depth > maxDepth || visited[url] || !body || body.length > 1024 * 1024) return Promise.resolve([]);
    visited[url] = true;
    var decoded = decode(body);
    if (!decoded) return Promise.resolve([]);
    var candidates = media(decoded, url).slice(0, 2);
    var accepted = [];
    var firstError;
    var chain = Promise.resolve();
    candidates.forEach(function (stream) {
      chain = chain.then(function () {
        if (accepted.length) return;
        return verified(stream).then(function (result) { if (result) accepted.push(result); }).catch(function (error) { firstError = firstError || error; });
      });
    });
    return chain.then(function () {
      if (accepted.length) return accepted;
      var frames = frameUrls(decoded, url, siteOrigin).slice(0, 3);
      var frameChain = Promise.resolve([]);
      frames.forEach(function (frameURL) {
        frameChain = frameChain.then(function (streams) {
          if (streams.length || visited[frameURL]) return streams;
          return get(frameURL, url).then(function (frameHTML) { return walk(frameHTML, frameURL, depth + 1); }).catch(function (error) { firstError = firstError || error; return []; });
        });
      });
      return frameChain.then(function (streams) {
        if (!streams.length && firstError) throw firstError;
        return streams;
      });
    });
  }
  return Promise.resolve().then(function () { return walk(String(html || ''), pageURL, 0); });
}

function resolveFrame(frameURL, referer, options) {
  options = options || {};
  var request = options.request || http.request;
  var url = httpsUrl(frameURL, referer);
  if (!url) return Promise.resolve([]);
  var settings = {};
  Object.keys(options).forEach(function (key) { settings[key] = options[key]; });
  settings.siteOrigin = settings.siteOrigin || u.origin(referer);
  return request(url, { referer: referer, origin: u.origin(referer), timeout: options.timeout || 10000 }).then(function (html) { return resolve(html, url, settings); });
}

module.exports = { resolve: resolve, resolveFrame: resolveFrame };
