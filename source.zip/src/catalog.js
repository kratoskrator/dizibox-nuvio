'use strict';
var u = require('./utils');

function readableHtml(value) {
  return typeof value === 'string' && value.length <= 4 * 1024 * 1024 ? value : '';
}

function safeUrl(value, base) {
  value = String(value || '');
  if (!value || /[\\\x00-\x20\x7f]/.test(value)) return '';
  var url = u.absolute(value, base);
  var host = /^https:\/\/([a-z0-9.-]+)(?::\d+)?(?:[/?#]|$)/i.exec(url);
  if (!host || /(?:^|\.)localhost\.?$/i.test(host[1]) || /^(?:127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(host[1]) || /^172\.(?:1[6-9]|2\d|3[01])\./.test(host[1])) return '';
  return url;
}

function pathOf(url) {
  return String(url || '').slice(u.origin(url).length).split(/[?#]/)[0];
}

function localUrl(value, base) {
  var url = safeUrl(value, base);
  if (!url || !u.sameSite(url, base) || /%(?:2f|5c|00|0a|0d)/i.test(url)) return '';
  return url.split(/[?#]/)[0];
}

function cleanTitle(value) {
  return u.text(value).replace(/[\u200e\u200f]/g, '').replace(/\s+izle\s*$/i, '').trim();
}

function cleanSlug(value) {
  return String(value || '').replace(/(?:-(?:izle|hd)(?:-\d+)?)+$/i, '').toLowerCase();
}

function seriesSlug(url) {
  var match = /^\/diziler\/([a-z0-9][a-z0-9-]*)\/?$/i.exec(pathOf(url));
  if (match) return cleanSlug(match[1]);
  match = /^\/dizi\/([a-z0-9][a-z0-9-]*)\/\d+-sezon-[a-z0-9-]+\/?$/i.exec(pathOf(url));
  return match ? cleanSlug(match[1]) : '';
}

function yearValue(value) {
  var match = /\b((?:19|20)\d{2})\b/.exec(String(value || ''));
  return match ? Number(match[1]) : null;
}

function trailingYear(value) {
  var match = /\s+[([]?((?:19|20)\d{2})[)\]]?\s*$/.exec(String(value || ''));
  return match ? Number(match[1]) : null;
}

function withoutYear(value) {
  return String(value || '').replace(/\s+[([]?(?:19|20)\d{2}[)\]]?\s*$/, '').trim();
}

function parseDirectory(html, base) {
  var results = [];
  var seen = {};
  var anchors = /<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi;
  var match;
  html = readableHtml(html).replace(/<!--[\s\S]*?-->/g, '');
  while ((match = anchors.exec(html)) !== null) {
    var url = localUrl(u.attr(match[1], 'href'), base);
    if (!seriesSlug(url)) continue;
    var attributeTitle = u.attr(match[1], 'title');
    var cardTitle = u.classText(match[2], 'tv-title');
    var title = cleanTitle(attributeTitle || cardTitle || match[2]);
    if (!title || title.length > 180 || /^(?:imdb\s*:?\s*)?\d\.\d$/i.test(title)) continue;
    var quality = attributeTitle ? 3 : cardTitle ? 2 : 1;
    var item = { url: url, title: title, type: 'tv' };
    var year = trailingYear(title);
    if (year) item.year = year;
    if (seen[url]) {
      var old = seen[url];
      if (quality > old.quality || quality === old.quality && title.length < results[old.index].title.length) {
        results[old.index] = item;
        old.quality = quality;
      }
    } else {
      seen[url] = { index: results.length, quality: quality };
      results.push(item);
    }
  }
  return results;
}

function titleList(metadata) {
  var titles = [metadata.title, metadata.originalTitle, metadata.turkishTitle];
  if (Array.isArray(metadata.titles)) titles = titles.concat(metadata.titles);
  return titles.filter(function (value) { return typeof value === 'string' && value; }).map(function (value) { return u.normalize(cleanTitle(value)); }).filter(Boolean);
}

function rankResults(results, metadata) {
  metadata = metadata || {};
  if (metadata.type && metadata.type !== 'tv' && metadata.type !== 'series') return [];
  var titles = titleList(metadata);
  var targetYear = yearValue(metadata.year);
  return (Array.isArray(results) ? results : []).map(function (item, index) {
    if (!item || !item.url || item.type && item.type !== 'tv') return null;
    var title = u.normalize(cleanTitle(item.title));
    var bareTitle = u.normalize(withoutYear(cleanTitle(item.title)));
    var slug = u.normalize(seriesSlug(item.url));
    var bareSlug = u.normalize(withoutYear(slug));
    var titleMatch = titles.indexOf(title) !== -1 || titles.indexOf(bareTitle) !== -1;
    var slugMatch = titles.indexOf(slug) !== -1 || titles.indexOf(bareSlug) !== -1;
    if (!titleMatch && !slugMatch) return null;
    var year = yearValue(item.year) || trailingYear(cleanTitle(item.title)) || trailingYear(slug);
    if (targetYear && year && targetYear !== year) return null;
    var score = (titleMatch ? 100 : 0) + (slugMatch ? 80 : 0) + (targetYear && targetYear === year ? 250 : 0);
    return { item: item, score: score, index: index };
  }).filter(Boolean).sort(function (a, b) { return b.score - a.score || a.index - b.index; }).map(function (entry) { return entry.item; });
}

function integer(value) {
  return value != null && /^\d+$/.test(String(value).trim()) ? Number(value) : null;
}

function episodeIdentity(url) {
  var match = /^\/([a-z0-9][a-z0-9-]*)-(\d+)-sezon-(\d+)-bolum(?:-[a-z0-9-]+)?\/?$/i.exec(pathOf(url));
  return match ? { series: cleanSlug(match[1]), season: Number(match[2]), episode: Number(match[3]) } : null;
}

function episodeUrl(html, seriesUrl, season, episode) {
  var wantedSeason = integer(season);
  var wantedEpisode = integer(episode);
  var series = seriesSlug(seriesUrl);
  if (!series || wantedSeason === null || wantedEpisode === null) return '';
  var anchors = /<a\b[^>]*>/gi;
  var match;
  html = readableHtml(html).replace(/<!--[\s\S]*?-->/g, '');
  while ((match = anchors.exec(html)) !== null) {
    var url = localUrl(u.attr(match[0], 'href'), seriesUrl);
    var identity = episodeIdentity(url);
    if (identity && identity.series === series && identity.season === wantedSeason && identity.episode === wantedEpisode) return url;
  }
  return '';
}

function elementBody(html, id) {
  var opening = /<([a-z][\w:-]*)\b([^>]*)>/gi;
  var match;
  while ((match = opening.exec(html)) !== null) {
    if (u.attr(match[2], 'id') !== id) continue;
    var closing = new RegExp('^([\\s\\S]*?)<\\/' + match[1] + '\\s*>', 'i');
    var body = closing.exec(html.slice(opening.lastIndex));
    return body ? body[1] : '';
  }
  return '';
}

function seasonUrl(html, seriesUrl, season) {
  var wantedSeason = integer(season);
  var series = seriesSlug(seriesUrl);
  if (!series || wantedSeason === null) return '';
  var body = elementBody(readableHtml(html), 'seasons-list');
  var anchors = /<a\b[^>]*>/gi;
  var match;
  while ((match = anchors.exec(body)) !== null) {
    var url = localUrl(u.attr(match[0], 'href'), seriesUrl);
    var seasonMatch = /^\/dizi\/([a-z0-9-]+)\/(\d+)-sezon-([a-z0-9-]+)\/?$/i.exec(pathOf(url));
    if (seasonMatch && cleanSlug(seasonMatch[1]) === series && cleanSlug(seasonMatch[3]) === series && Number(seasonMatch[2]) === wantedSeason) return url;
  }
  return '';
}

function pageIdentity(html) {
  html = readableHtml(html);
  var section = /<section\b[^>]*\bid\s*=\s*(?:"single-diziler"|'single-diziler')[^>]*>/i.exec(html);
  if (!section) return {};
  var body = html.slice(section.index, section.index + 30000).split(/<[^>]+\bid\s*=\s*(?:"seasons-list"|'seasons-list')/i)[0];
  var heading = /<h1\b[^>]*>([\s\S]*?)<\/h1\s*>/i.exec(body);
  var year = /href\s*=\s*["'][^"']*\/yil\/((?:19|20)\d{2})\/?["']/i.exec(body);
  var identity = {};
  if (heading) identity.title = cleanTitle(heading[1]);
  if (year) identity.year = Number(year[1]);
  return identity;
}

function playerChoices(html, pageUrl) {
  html = readableHtml(html);
  var result = [];
  var seen = {};
  var body = elementBody(html, 'video-area');
  var label = /<!--\s*baslik\s*:\s*([^<]*?)\s*-->/i.exec(body);
  var frames = body.match(/<iframe\b[^>]*>/gi) || [];
  frames.forEach(function (tag) {
    var url = safeUrl(u.attr(tag, 'src') || u.attr(tag, 'data-src'), pageUrl);
    if (!url || seen[url]) return;
    seen[url] = true;
    result.push({ url: url, kind: 'iframe', name: label ? u.text(label[1]) : 'DiziBOX' });
  });
  var episodePath = pathOf(pageUrl).replace(/\/\d+\/?$/, '/').replace(/\/?$/, '/');
  if (!episodeIdentity(u.origin(pageUrl) + episodePath)) return result;
  var selects = /<select\b([^>]*)>([\s\S]*?)<\/select\s*>/gi;
  var match;
  while ((match = selects.exec(html)) !== null) {
    if ((' ' + u.attr(match[1], 'class') + ' ').indexOf(' woca-linkpages-dd ') === -1) continue;
    var options = /<option\b([^>]*)>([\s\S]*?)<\/option\s*>/gi;
    var option;
    while ((option = options.exec(match[2])) !== null) {
      var url = localUrl(u.attr(option[1], 'value') || u.attr(option[1], 'href'), pageUrl);
      var path = pathOf(url);
      if (!url || path !== episodePath && !new RegExp('^' + episodePath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[1-9]\\d*/?$').test(path) || seen[url] || path === pathOf(pageUrl)) continue;
      seen[url] = true;
      result.push({ url: url, kind: 'page', name: u.text(option[2]) || 'DiziBOX' });
    }
  }
  return result;
}

module.exports = { parseDirectory: parseDirectory, rankResults: rankResults, episodeUrl: episodeUrl, seasonUrl: seasonUrl, pageIdentity: pageIdentity, playerChoices: playerChoices };
