'use strict';
var u = require('./utils');
var http = require('./http');
var catalog = require('./catalog');
var player = require('./player');
var DEFAULT_SITE = 'https://www.dizibox.live';

function settings() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var saved = root.SCRAPER_SETTINGS || {};
  return { site: u.siteUrl(saved.siteUrl || DEFAULT_SITE) || DEFAULT_SITE, key: String(saved.tmdbApiKey || root.TMDB_API_KEY || '').trim(), session: http.session() };
}

function metadata(id, cfg) {
  if (!cfg.key) return Promise.reject(new Error('TMDB key unavailable. Enter your own key in DiziBOX TV settings.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/tv/' + encodeURIComponent(id) + '?language=tr-TR';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '', session: cfg.session }).then(function (data) {
    return { title: data.name || '', originalTitle: data.original_name || '', year: Number(String(data.first_air_date || '').slice(0, 4)) || null };
  });
}

function directory(cfg) {
  // The public directory is server-rendered; the site's search endpoints can stall.
  return http.request(cfg.site + '/', { session: cfg.session }).then(function (html) {
    return catalog.parseDirectory(html, cfg.site);
  });
}

function episodePage(match, meta, cfg, season, episode) {
  return http.request(match.url, { referer: cfg.site + '/', session: cfg.session }).then(function (html) {
    var identity = catalog.pageIdentity(html);
    if (identity.year && meta.year && identity.year !== meta.year) return null;
    var target = catalog.episodeUrl(html, match.url, season, episode);
    if (target) return { url: target, referer: match.url };
    var selectedSeason = catalog.seasonUrl(html, match.url, season);
    if (!selectedSeason || selectedSeason === match.url) return null;
    return http.request(selectedSeason, { referer: match.url, session: cfg.session }).then(function (body) {
      var link = catalog.episodeUrl(body, match.url, season, episode);
      return link ? { url: link, referer: selectedSeason } : null;
    });
  }).then(function (target) {
    if (!target) return null;
    return http.request(target.url, { referer: target.referer, session: cfg.session }).then(function (html) { return { html: html, url: target.url }; });
  });
}

function extract(page, cfg) {
  var choices = catalog.playerChoices(page.html, page.url);
  var visitedFrames = {};
  function request(url, options) {
    options = options || {};
    options.session = cfg.session;
    return http.request(url, options);
  }
  function frames(html, url) {
    var found = catalog.playerChoices(html, url).filter(function (choice) { return choice.kind === 'iframe'; }).slice(0, 2);
    function next(index) {
      if (index >= found.length) return Promise.resolve([]);
      var frame = found[index];
      if (visitedFrames[frame.url]) return next(index + 1);
      visitedFrames[frame.url] = true;
      return player.resolveFrame(frame.url, url, { request: request, siteOrigin: cfg.site }).then(function (streams) {
        streams.forEach(function (stream) { stream.sourceName = frame.name || 'Player'; });
        return streams.length ? streams : next(index + 1);
      }).catch(function (error) {
        console.warn('[DiziBOX TV] ' + error.message);
        return next(index + 1);
      });
    }
    return next(0);
  }
  return frames(page.html, page.url).then(function (streams) {
    if (streams.length) return streams;
    var pages = choices.filter(function (choice) { return choice.kind === 'page' && choice.url !== page.url; }).slice(0, 2);
    function next(index) {
      if (index >= pages.length) return Promise.resolve([]);
      return request(pages[index].url, { referer: page.url }).then(function (body) { return frames(body, pages[index].url); }).then(function (result) { return result.length ? result : next(index + 1); }).catch(function (error) {
        console.warn('[DiziBOX TV] ' + error.message);
        return next(index + 1);
      });
    }
    return next(0);
  });
}

function getStreams(tmdbId, mediaType, season, episode) {
  if (['tv', 'series', 'show'].indexOf(mediaType) === -1) return Promise.resolve([]);
  if (!/^\d+$/.test(String(tmdbId)) || !/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(episode) < 1) return Promise.resolve([]);
  var cfg = settings();
  if (!cfg.key) return metadata(tmdbId, cfg).catch(function (error) { console.warn('[DiziBOX TV] ' + error.message); return []; });
  return Promise.all([metadata(tmdbId, cfg), directory(cfg)]).then(function (values) {
    var meta = values[0];
    var matches = catalog.rankResults(values[1], meta).slice(0, 2);
    return Promise.resolve().then(function () {
      function next(index) {
        if (index >= matches.length) return Promise.resolve([]);
        return episodePage(matches[index], meta, cfg, season, episode).then(function (page) { return page ? extract(page, cfg) : []; }).then(function (streams) {
          return streams.length ? streams : next(index + 1);
        });
      }
      return next(0);
    }).then(function (streams) {
      var seen = {};
      return streams.filter(function (stream) { if (!stream.url || seen[stream.url]) return false; seen[stream.url] = true; return true; }).map(function (stream) {
        var headers = stream.headers || {};
        var subtitles = (stream.subtitles || []).map(function (sub, index) {
          return { id: sub.id || 'dizibox-' + index, url: sub.url, language: sub.language || sub.lang || 'und', name: sub.name || sub.label || sub.language || 'Subtitle', headers: sub.headers || headers };
        });
        return { name: 'DiziBOX TV', provider: 'DiziBOX TV', title: meta.title + ' S' + season + 'E' + episode + ' | ' + (stream.sourceName || 'Player'), url: stream.url, quality: stream.quality || 'Auto', type: stream.type || 'hls', headers: headers, subtitles: subtitles };
      });
    });
  }).then(function (streams) { http.cancel(cfg.session); return streams; }).catch(function (error) {
    http.cancel(cfg.session);
    // Only helper errors or fixed local messages reach this log, never tokens or URLs with queries.
    console.warn('[DiziBOX TV] ' + error.message);
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'DiziBOX TV' },
    { type: 'text', key: 'siteUrl', label: 'Website address', defaultValue: DEFAULT_SITE, description: 'Update this HTTPS origin if the website moves.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s key when available. Otherwise enter your own v3 key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };
