'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const code = fs.readFileSync(path.join(__dirname, '../dizibox.js'), 'utf8');
const site = 'https://www.dizibox.live';
const series = site + '/diziler/example-izle-2/';
const episode = site + '/example-1-sezon-1-bolum-hd-1-izle/';
const frame = site + '/player/king/king.php?v=fixture';
const embed = 'https://dbx.molystream.org/embed/fixture';
const hls = 'https://dbx.molystream.org/embed/sheila/fixture';
const directory = '<a href="' + site + '/diziler/different/">Different</a><a href="' + series + '">Example</a>';
const identity = '<section id="single-diziler"><h1>Example</h1><a href="/yil/2020/">2020</a></section>';
const options = '<select class="woca-linkpages-dd"><option value="' + episode + '">DBX Pro</option><option value="' + episode + '2/">Alternate</option></select>';
function routes() { return [
  [/^https:\/\/api\.themoviedb\.org\/3\/tv\/99\?/, { name: 'Example', original_name: 'Example', first_air_date: '2020-01-01' }],
  [site + '/', directory],
  [series, identity + '<a href="' + episode + '">1.Sezon 1.Bölüm</a>'],
  [episode, '<div id="video-area"><!--baslik: DBX Pro--><iframe src="' + frame + '"></iframe></div>' + options],
  [frame, '<div id="Player"><iframe src="' + embed + '"></iframe></div>'],
  [embed, "jwplayer('fixture').setup({file:'" + hls + "',type:'application/vnd.apple.mpegurl'});"],
  [hls, '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3000000\n/fixture/index.m3u8\n']
]; }
function harness(entries, globals) {
  const requests = [], warnings = [];
  const context = vm.createContext(Object.assign({ module: { exports: {} }, TMDB_API_KEY: 'fixture-only-key', require: id => { if (id === 'crypto-js') return require('crypto-js'); throw new Error('Unexpected module'); }, console: { warn: s => warnings.push(s) }, fetch: (url, init) => {
    requests.push({ url, init });
    const entry = entries.find(r => typeof r[0] === 'string' ? r[0] === url : r[0].test(url));
    if (!entry) return Promise.reject(new Error('Unexpected fixture request'));
    const status = entry[2] || 200;
    return Promise.resolve({ status, ok: status >= 200 && status < 300, headers: { get: name => (entry[3] || {})[name] || null }, text: () => Promise.resolve(typeof entry[1] === 'string' ? entry[1] : JSON.stringify(entry[1])) });
  } }, globals || {}));
  vm.runInContext(code, context, { timeout: 1000 });
  return { plugin: context.module.exports, requests, warnings, context };
}

test('bundle uses the directory, exact episode and real player source without site search requests', async () => {
  const h = harness(routes());
  const streams = await h.plugin.getStreams('99', 'tv', 1, 1);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, hls);
  assert.equal(streams[0].quality, 'Auto');
  assert.equal(streams[0].headers.Referer, embed);
  assert.equal(streams[0].type, 'hls');
  assert.equal(h.requests.length, 7);
  assert.equal(h.warnings.length, 0);
  assert.ok(!h.requests.some(r => /admin-ajax|\?s=/.test(r.url)));
  assert.equal(vm.runInContext('typeof Buffer+","+typeof URL+","+typeof setTimeout', h.context), 'undefined,undefined,undefined');
});

test('follows the listed season page for a later season', async () => {
  const entries = routes();
  const seasonUrl = site + '/dizi/example/2-sezon-example/';
  const target = site + '/example-2-sezon-3-bolum-izle/';
  entries[2][1] = identity + '<div id="seasons-list"><a href="' + seasonUrl + '">2. Sezon</a></div>';
  entries[3][0] = target;
  entries.push([seasonUrl, '<a href="' + site + '/other-2-sezon-3-bolum/">Wrong show</a><a href="' + target + '">Requested episode</a>']);
  const h = harness(entries);
  const streams = await h.plugin.getStreams('99', 'series', 2, 3);
  assert.equal(streams.length, 1);
  assert.match(streams[0].title, /S2E3/);
  assert.ok(h.requests.some(r => r.url === seasonUrl));
  assert.ok(!h.requests.some(r => r.url.includes('/other-')));
});

test('unavailable primary player falls back only to a listed alternate page', async () => {
  const entries = routes(); entries[4][1] = '<p>Source unavailable</p>';
  const altFrame = site + '/player/moly/moly.php?h=fixture';
  entries.push([episode + '2/', '<div id="video-area"><iframe src="' + altFrame + '"></iframe></div>']);
  entries.push([altFrame, "jwplayer('fixture').setup({file:'" + hls + "',type:'hls'});"]);
  const h = harness(entries);
  assert.equal((await h.plugin.getStreams('99', 'tv', 1, 1)).length, 1);
  assert.ok(h.requests.some(r => r.url === episode + '2/'));
});

test('wrong remake year and unlisted episodes return no sources', async () => {
  const entries = routes(); entries[2][1] = identity.replace('/yil/2020/', '/yil/1990/');
  const h = harness(entries);
  assert.equal((await h.plugin.getStreams('99', 'tv', 1, 1)).length, 0);
  assert.equal(h.requests.length, 3);
  const missing = harness(routes());
  assert.equal((await missing.plugin.getStreams('99', 'tv', 1, 9)).length, 0);
  assert.equal(missing.requests.length, 3);
});

test('blocked or invalid HLS sources are omitted, with no verification retries', async () => {
  const entries = routes(); entries[6][1] = '<html>Not a playlist</html>';
  const invalid = harness(entries);
  assert.equal((await invalid.plugin.getStreams('99', 'tv', 1, 1)).length, 0);
  const blockedRoutes = routes(); blockedRoutes[5][2] = 403;
  const blocked = harness(blockedRoutes);
  assert.equal((await blocked.plugin.getStreams('99', 'tv', 1, 1)).length, 0);
  assert.equal(blocked.requests.filter(row => row.url === embed).length, 1);
  assert.match(blocked.warnings[0], /Site access blocked/);
  assert.ok(!blocked.warnings.join(' ').includes('fixture-only-key'));
});

test('movie input, malformed requests and absent metadata key do not reach the site', async () => {
  const h = harness([]);
  for (const args of [['99', 'movie'], ['abc', 'tv', 1, 1], ['99', 'tv', 1, 0], ['99', 'tv', -1, 1]]) assert.equal((await h.plugin.getStreams(...args)).length, 0);
  assert.equal(h.requests.length, 0);
  const noKey = harness([], { TMDB_API_KEY: '' });
  assert.equal((await noKey.plugin.getStreams('99', 'tv', 1, 1)).length, 0);
  assert.equal(noKey.requests.length, 0);
  assert.match(noKey.warnings[0], /TMDB key unavailable/);
});

test('settings override metadata key, and read tokens stay out of URL queries', async () => {
  const token = 'fixture-read-token-'.repeat(4);
  const h = harness(routes(), { SCRAPER_SETTINGS: { tmdbApiKey: token } });
  assert.equal((await h.plugin.getStreams('99', 'show', 1, 1)).length, 1);
  assert.equal(h.requests[0].init.headers.Authorization, 'Bearer ' + token);
  assert.ok(!h.requests[0].url.includes(token));
  assert.equal((await h.plugin.onSettings()).find(f => f.key === 'tmdbApiKey').isPassword, true);
});

test('site cookies are never manually forwarded across native redirects', async () => {
  const entries = routes(); entries[1][3] = { 'set-cookie': 'PHPSESSID=fixture-session; Path=/; HttpOnly' };
  const h = harness(entries);
  await h.plugin.getStreams('99', 'tv', 1, 1);
  assert.ok(h.requests.every(row => row.init.headers.Cookie === undefined));
  await h.plugin.getStreams('99', 'tv', 1, 1);
  assert.equal(h.requests[7].init.headers.Cookie, undefined);
});

test('metadata and directory begin together, then metadata controls exact matching', async () => {
  const entries = routes();
  let release;
  const metadata = new Promise(resolve => { release = resolve; });
  const h = harness(entries);
  const originalFetch = h.context.fetch;
  h.context.fetch = (url, init) => /api\.themoviedb/.test(url) ? metadata.then(() => originalFetch(url, init)) : originalFetch(url, init);
  const pending = h.plugin.getStreams('99', 'tv', 1, 1);
  await new Promise(resolve => setImmediate(resolve));
  assert.ok(h.requests.some(row => row.url === site + '/'));
  assert.ok(!h.requests.some(row => row.url === series));
  release();
  assert.equal((await pending).length, 1);
});

test('detail year must match exactly even when the directory has no year', async () => {
  const entries = routes(); entries[2][1] = identity.replace('/yil/2020/', '/yil/2021/');
  const h = harness(entries);
  assert.equal((await h.plugin.getStreams('99', 'tv', 1, 1)).length, 0);
  assert.equal(h.requests.length, 3);
});
