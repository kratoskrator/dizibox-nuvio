'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const player = require('../src/player');

const site = 'https://www.dizibox.live';
const episode = site + '/fixture-1-sezon-1-bolum/';
const wrapper = site + '/player/king/king.php?v=fixture';
const embed = 'https://dbx.molystream.org/embed/fixture';
const endpoint = 'https://dbx.molystream.org/embed/sheila/fixture';
const master = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\n/fixture/level.m3u8\n';
const jw = (file = endpoint, extra = '') => "jwplayer('fixture').setup({file:'" + file + "',type:'application/vnd.apple.mpegurl',autostart:playControl" + extra + '});';

// Construct the documented OpenSSL passphrase format independently of CryptoJS.
function encryptedHTML(plain, passphrase = 'U2FsdGVkX19fixture-password=') {
  const salt = Buffer.from('fixture!', 'utf8');
  let previous = Buffer.alloc(0);
  let derived = Buffer.alloc(0);
  while (derived.length < 48) {
    previous = crypto.createHash('md5').update(Buffer.concat([previous, Buffer.from(passphrase), salt])).digest();
    derived = Buffer.concat([derived, previous]);
  }
  const cipher = crypto.createCipheriv('aes-256-cbc', derived.subarray(0, 32), derived.subarray(32, 48));
  const payload = Buffer.concat([Buffer.from('Salted__'), salt, cipher.update(plain), cipher.final()]).toString('base64');
  return 'CryptoJS.AES.decrypt(' + JSON.stringify(payload) + ',' + JSON.stringify(passphrase) + ');';
}

function mock(routes, options = {}) {
  const calls = [];
  return {
    calls,
    options: Object.assign({}, options, { request(url, init) {
      calls.push({ url, init });
      if (!Object.prototype.hasOwnProperty.call(routes, url)) return Promise.reject(new Error('Unexpected fixture URL'));
      const result = routes[url];
      return result instanceof Error ? Promise.reject(result) : Promise.resolve(result);
    } })
  };
}

test('resolves the ordinary episode, wrapper, AES, HLS chain and keeps the embed Referer', async () => {
  const fixture = mock({
    [wrapper]: '<div id="Player"><iframe src="' + embed + '"></iframe></div>',
    [embed]: encryptedHTML('<script>globalThis.diziboxFixtureExecuted=true;' + jw() + '</script>'),
    [endpoint]: master
  });
  delete globalThis.diziboxFixtureExecuted;
  const streams = await player.resolve('<iframe src="' + wrapper + '"></iframe>', episode, fixture.options);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, endpoint);
  assert.equal(streams[0].quality, 'Auto');
  assert.equal(streams[0].type, 'hls');
  assert.deepEqual(fixture.calls.map(call => [call.url, call.init.referer]), [[wrapper, episode], [embed, wrapper], [endpoint, embed]]);
  assert.equal(streams[0].headers.Referer, embed);
  assert.equal(streams[0].headers.Origin, 'https://dbx.molystream.org');
  assert.equal(globalThis.diziboxFixtureExecuted, undefined);
});

test('extracts only actual subtitle tracks, retains escaped query strings, and does not report image or preview files', async () => {
  const playlist = 'https://cdn.example.test/master.m3u8?x=1&y=2';
  const fixture = mock({ [playlist]: master });
  const html = 'jwplayer("fixture").setup({sources:[{file:"https:\\/\\/cdn.example.test/master.m3u8?x=1\\u0026y=2",type:"hls"}],tracks:[null,{file:"/subs/tr.vtt",kind:"captions",label:"Türkçe",srclang:"tr"},{file:"/previews/storyboard.vtt",kind:"thumbnails"}],image:"https://ads.example.test/poster.jpg"});';
  const streams = await player.resolve(html, embed, fixture.options);
  assert.equal(streams.length, 1);
  assert.deepEqual(streams[0].subtitles, [{ id: 'dizibox-0', url: 'https://dbx.molystream.org/subs/tr.vtt', language: 'tr', name: 'Türkçe', headers: streams[0].headers }]);
});

test('rejects an HTTP 200 HTML error from a declared HLS endpoint', async () => {
  const fixture = mock({ [endpoint]: '<html><title>Unavailable</title></html>' });
  assert.deepEqual(await player.resolve(jw(), embed, fixture.options), []);
});

test('follows an endpoint response containing one public HTTPS playlist URL', async () => {
  const target = 'https://cdn.example.test/path/master.m3u8?fixture=1';
  const fixture = mock({ [endpoint]: target, [target]: master });
  const streams = await player.resolve(jw(), embed, fixture.options);
  assert.equal(streams[0].url, target);
  assert.equal(streams[0].headers.Referer, embed);
  assert.equal(fixture.calls[1].init.referer, embed);
});

test('recognizes relative direct video sources while refusing unsafe URLs', async () => {
  const target = 'https://dbx.molystream.org/embed/media/master.m3u8';
  const fixture = mock({ [target]: master });
  const html = '<video><source src="media/master.m3u8" type="application/x-mpegURL"></video><source src="javascript:alert(1)" type="application/x-mpegURL"><source src="http://insecure.test/master.m3u8" type="application/x-mpegURL">';
  const streams = await player.resolve(html, embed, fixture.options);
  assert.equal(streams.length, 1);
  assert.equal(streams[0].url, target);
});

test('ignores advertising and challenge frames rather than following every iframe', async () => {
  const fixture = mock({});
  assert.deepEqual(await player.resolve('<iframe src="https://ads.example.test/embed/a"></iframe><iframe src="/cdn-cgi/challenge-platform/frame"></iframe><iframe src="https://user:secret@dbx.molystream.org/embed/a"></iframe>', episode, fixture.options), []);
  assert.equal(fixture.calls.length, 0);
});

test('rejects AES expressions and unsupported encrypted data without executing them', async () => {
  const fixture = mock({});
  assert.deepEqual(await player.resolve('CryptoJS.AES.decrypt("U2FsdGVkX19AAA==", getPassword());', embed, fixture.options), []);
  assert.deepEqual(await player.resolve('CryptoJS.AES.decrypt("not-salted", "fixture");', embed, fixture.options), []);
  assert.equal(fixture.calls.length, 0);
});

test('accepts a supported alternative frame after a blocked first frame', async () => {
  const alternative = site + '/player/moly/moly.php?h=fixture';
  const fixture = mock({ [wrapper]: new Error('Site access blocked (HTTP 403)'), [alternative]: jw(), [endpoint]: master });
  const streams = await player.resolve('<iframe src="' + wrapper + '"></iframe><iframe src="' + alternative + '"></iframe>', episode, fixture.options);
  assert.equal(streams.length, 1);
});

test('surfaces a blocked connection when no playable alternative succeeds', async () => {
  const fixture = mock({ [endpoint]: new Error('Site access blocked (HTTP 403)') });
  await assert.rejects(player.resolve(jw(), embed, fixture.options), /HTTP 403/);
});

test('halts on a browser-verification block without attempting more frames', async () => {
  const blocked = new Error('Site access blocked (HTTP 403)');
  blocked.siteBlocked = true;
  const alternative = site + '/player/moly/moly.php?h=fixture';
  const fixture = mock({ [wrapper]: blocked, [alternative]: jw(), [endpoint]: master });
  await assert.rejects(player.resolve('<iframe src="' + wrapper + '"></iframe><iframe src="' + alternative + '"></iframe>', episode, fixture.options), /HTTP 403/);
  assert.equal(fixture.calls.length, 1);
});

test('bounds requests and detects frame cycles', async () => {
  const fixture = mock({ [wrapper]: '<iframe src="' + wrapper + '"></iframe>' });
  assert.deepEqual(await player.resolve('<iframe src="' + wrapper + '"></iframe>', episode, fixture.options), []);
  assert.equal(fixture.calls.length, 1);
  const limited = mock({ [wrapper]: '<iframe src="' + embed + '"></iframe>' }, { maxRequests: 1 });
  assert.deepEqual(await player.resolve('<iframe src="' + wrapper + '"></iframe>', episode, limited.options), []);
  assert.equal(limited.calls.length, 1);
});

test('resolveFrame preserves its caller Referer and accepts only verified playlists', async () => {
  const fixture = mock({ [wrapper]: jw(), [endpoint]: master });
  const streams = await player.resolveFrame(wrapper, episode, fixture.options);
  assert.equal(streams.length, 1);
  assert.equal(fixture.calls[0].init.referer, episode);
  assert.equal(streams[0].headers.Referer, wrapper);
});
