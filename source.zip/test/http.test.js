'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
function harness(fetch, globals = {}) {
  const context = vm.createContext(Object.assign({ module: {exports:{}}, require: () => require('../src/utils'), fetch, Promise }, globals));
  vm.runInContext(fs.readFileSync(require.resolve('../src/http'), 'utf8'), context);
  return context.module.exports;
}
function response(body, status = 200, headers = {}) { return { status, ok: status >= 200 && status < 300, headers: {get: name => headers[name] || ''}, text: () => Promise.resolve(body) }; }

test('enforces native byte limits including exact-quota and UTF-8 bodies', async () => {
  for (const body of ['a'.repeat(1024*1024), 'ş'.repeat(512*1024)]) {
    const http = harness(() => Promise.resolve(response(body)));
    await assert.rejects(http.request('https://site.test/'), /size limit/);
  }
});

test('keeps no cookie jar and refuses caller Cookie headers', async () => {
  const calls = [];
  const http = harness((url, init) => { calls.push(init); return Promise.resolve(response('ok', 200, {'set-cookie':'session=private'})); });
  const session = http.session();
  await http.request('https://site.test/', {session});
  await http.request('https://site.test/next', {session, headers:{Cookie:'session=private'}});
  assert.ok(calls.every(init => !init.headers.Cookie));
});

test('one origin block is cached, while an independent host can still work', async () => {
  let count = 0;
  const http = harness(url => { count++; return Promise.resolve(response('body', url.includes('blocked.test') ? 403 : 200)); });
  const session = http.session();
  await assert.rejects(http.request('https://blocked.test/one', {session}), /HTTP 403/);
  await assert.rejects(http.request('https://blocked.test/two', {session}), /HTTP 403/);
  assert.equal(await http.request('https://other.test/', {session}), 'body');
  assert.equal(count, 2);
});

test('only transient GET failures receive one bounded retry', async () => {
  let count = 0;
  const http = harness(() => { count++; return Promise.resolve(response('ok', count === 1 ? 503 : 200)); });
  assert.equal(await http.request('https://site.test/'), 'ok');
  assert.equal(count, 2);
  let posts = 0;
  const post = harness(() => { posts++; return Promise.resolve(response('unavailable', 503)); });
  await assert.rejects(post.request('https://site.test/', {body:'a=b'}), /HTTP 503/);
  assert.equal(posts, 1);
});

test('cancels pending requests and prevents new requests without guest timers', async () => {
  let calls = 0, aborted = 0;
  class Controller { constructor() { this.signal = {}; } abort() { aborted++; } }
  const http = harness(() => { calls++; return new Promise(() => {}); }, {AbortController:Controller});
  const session = http.session();
  const pending = http.request('https://site.test/', {session});
  await new Promise(resolve => setImmediate(resolve));
  http.cancel(session);
  await assert.rejects(pending, /Lookup cancelled/);
  await assert.rejects(http.request('https://site.test/next', {session}), /Lookup cancelled/);
  assert.equal(calls, 1); assert.equal(aborted, 1); assert.equal(session.pending.length, 0);
});

test('overall lookup deadline prevents requests after the budget is exhausted', async () => {
  let calls = 0;
  const http = harness(() => { calls++; return Promise.resolve(response('ok')); });
  const session = http.session(); session.deadline = 0;
  await assert.rejects(http.request('https://site.test/', {session}), /budget exhausted/);
  assert.equal(calls, 0);
});
