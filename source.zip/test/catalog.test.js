'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const catalog = require('../src/catalog');
const base = 'https://www.dizibox.live';
const series = base + '/diziler/breaking-bad-izle-2/';
const episode = base + '/breaking-bad-1-sezon-1-bolum-hd-1-izle/';

test('directory prefers real navigation titles over rating and genre cards', () => {
  const html = '<a href="/diziler/show-hd-2/">8.2</a>' +
    '<a href="/diziler/show-hd-2/"><div class="tv-title">Show izle</div><div>Drama, Crime</div></a>' +
    '<a title="Show izle" href="/diziler/show-hd-2/"><i></i>Show</a>' +
    '<a title="İkinci &amp; Dizi 2024 izle" href="/diziler/ikinci-dizi-2024/">İkinci &amp; Dizi 2024</a>';
  assert.deepEqual(catalog.parseDirectory(html, base), [
    { url: base + '/diziler/show-hd-2/', title: 'Show', type: 'tv' },
    { url: base + '/diziler/ikinci-dizi-2024/', title: 'İkinci & Dizi 2024', type: 'tv', year: 2024 }
  ]);
});

test('directory excludes ads, episodes, credentials and hidden comments', () => {
  const urls = ['/show-1-sezon-1-bolum/', '/diziler/', 'https://ads.test/diziler/show/', '//ads.test/diziler/show/', 'https://www.dizibox.live@ads.test/diziler/show/', 'https://www.dizibox.live\\@ads.test/diziler/show/', '/diziler/%2fshow/', 'javascript:alert(1)'];
  const html = urls.map(url => '<a href="' + url + '">Show</a>').join('') +
    '<!-- <a href="/diziler/hidden/">Hidden</a> -->';
  assert.deepEqual(catalog.parseDirectory(html, base), []);
});

test('ranks exact titles and original-title slugs without prefix collisions', () => {
  const results = [
    { url: base + '/diziler/show-returns/', title: 'Show Returns' },
    { url: base + '/diziler/show-hd-2/', title: 'Yerel Başlık' },
    { url: base + '/diziler/yerel-izle-1/', title: 'Show' }
  ];
  assert.deepEqual(catalog.rankResults(results, { title: 'Show' }).map(item => item.url), [results[2].url, results[1].url]);
  assert.deepEqual(catalog.rankResults(results, { title: 'Unknown' }), []);
  assert.deepEqual(catalog.rankResults(results, { title: 'Show', type: 'movie' }), []);
  assert.equal(catalog.rankResults(results, { originalTitle: 'Show', title: 'Başlık' }).length, 2);
});

test('remakes with a named year require the requested year and outrank unknown years', () => {
  const results = [
    { url: base + '/diziler/utopia/', title: 'Utopia' },
    { url: base + '/diziler/utopia-2020/', title: 'Utopia 2020' },
    { url: base + '/diziler/utopia-2013/', title: 'Utopia 2013', year: 2013 }
  ];
  assert.deepEqual(catalog.rankResults(results, { title: 'Utopia', year: 2020 }).map(item => item.url), [results[1].url, results[0].url]);
  assert.deepEqual(catalog.rankResults(results, { title: 'Utopia', year: 2013 }).map(item => item.url), [results[2].url, results[0].url]);
});

test('episode selection uses exact listed season and episode for the requested show', () => {
  const html = '<a href="/better-call-saul-1-sezon-1-bolum/">Wrong show</a>' +
    '<a href="/breaking-bad-11-sezon-1-bolum/">Wrong season</a>' +
    '<a href="/breaking-bad-1-sezon-11-bolum/">Wrong episode</a>' +
    '<a href="' + episode + '">Pilot</a>' +
    '<a href="/breaking-bad-1-sezon-7-bolum-sezon-finali-izle/">Finale</a>';
  assert.equal(catalog.episodeUrl(html, series, '1', '1'), episode);
  assert.equal(catalog.episodeUrl(html, series, 1, 7), base + '/breaking-bad-1-sezon-7-bolum-sezon-finali-izle/');
  assert.equal(catalog.episodeUrl(html, series, 2, 1), '');
  assert.equal(catalog.episodeUrl(html, series, undefined, 1), '');
  assert.equal(catalog.episodeUrl(html, series, 1.2, 1), '');
});

test('episode selection supports season zero and never invents a route', () => {
  const html = '<a href="/breaking-bad-0-sezon-1-bolum/">Special</a>';
  assert.equal(catalog.episodeUrl(html, series, 0, 1), base + '/breaking-bad-0-sezon-1-bolum/');
  assert.equal(catalog.episodeUrl('', series, 1, 1), '');
  assert.equal(catalog.episodeUrl('<!--' + html + '-->', series, 0, 1), '');
});

test('season page links must be in the season list and name the same show twice', () => {
  const html = '<a href="/dizi/breaking-bad/2-sezon-breaking-bad/">Outside</a>' +
    '<div id="seasons-list"><a href="https://ads.test/dizi/breaking-bad/2-sezon-breaking-bad/">Ad</a>' +
    '<a href="/dizi/breaking-bad/2-sezon-other/">Wrong</a>' +
    '<a href="/dizi/breaking-bad/12-sezon-breaking-bad/">Twelve</a>' +
    '<a href="/dizi/breaking-bad/2-sezon-breaking-bad/">Two</a></div>';
  assert.equal(catalog.seasonUrl(html, series, 2), base + '/dizi/breaking-bad/2-sezon-breaking-bad/');
  assert.equal(catalog.seasonUrl(html, series, 1), '');
});

test('identity ignores years and titles in the global series directory', () => {
  const html = '<a href="/yil/2025/">2025</a><h1>Wrong global heading</h1>' +
    '<section id="single-diziler"><h1><a>Breaking Bad</a></h1><span><a href="/yil/2008/">2008</a></span>' +
    '<div id="seasons-list"><a href="/yil/2099/">2099</a></div></section>';
  assert.deepEqual(catalog.pageIdentity(html), { title: 'Breaking Bad', year: 2008 });
  assert.deepEqual(catalog.pageIdentity('<h1>Directory</h1>'), {});
});

test('player extraction limits frames to video area and alternative pages to this episode', () => {
  const html = '<iframe src="https://ads.test/banner"></iframe>' +
    '<select class="woca-linkpages-dd selectBox"><option href="' + episode + '" selected>DBX Pro</option>' +
    '<option value="' + episode + '2/">Moly+</option><option value="' + episode + '3/">Odnok</option>' +
    '<option value="https://ads.test' + episode.slice(base.length) + '2/">Ad</option>' +
    '<option value="/breaking-bad-1-sezon-2-bolum/">Wrong episode</option></select>' +
    '<div id="video-area"><p><!--baslik:DBX Pro--><span><iframe src="/player/king/king.php?v=test-id"></iframe></span></p></div>';
  assert.deepEqual(catalog.playerChoices(html, episode), [
    { url: base + '/player/king/king.php?v=test-id', kind: 'iframe', name: 'DBX Pro' },
    { url: episode + '2/', kind: 'page', name: 'Moly+' },
    { url: episode + '3/', kind: 'page', name: 'Odnok' }
  ]);
});

test('player extraction preserves signed query strings and rejects unsafe frame URLs', () => {
  const html = '<div id="video-area"><iframe src="https://video.example/embed?v=test&amp;t=example"></iframe>' +
    '<iframe src="javascript:bad()"></iframe><iframe src="http://127.0.0.1/media"></iframe>' +
    '<iframe src="https://localhost/media"></iframe><iframe src="https://10.0.0.1/media"></iframe></div>';
  assert.deepEqual(catalog.playerChoices(html, episode), [{ url: 'https://video.example/embed?v=test&t=example', kind: 'iframe', name: 'DiziBOX' }]);
});

test('non-Latin metadata cannot match a different show through an empty normalized title', () => {
  const items = [{ url: base + '/diziler/different/', title: '別の番組', type: 'tv' }];
  assert.deepEqual(catalog.rankResults(items, { title: 'Unknown show', originalTitle: '오징어 게임' }), []);
});

test('saved public HTML fixtures resolve the actual listed episode and season paths', { skip: !fs.existsSync(path.resolve(__dirname, '../../../work/dizibox/home.html')) }, () => {
  const fixture = name => fs.readFileSync(path.resolve(__dirname, '../../../work/dizibox/' + name + '.html'), 'utf8');
  const directory = catalog.parseDirectory(fixture('home'), base);
  assert.ok(directory.length > 2000);
  assert.equal(catalog.rankResults(directory, { title: 'Breaking Bad', year: 2008 })[0].url, series);
  assert.equal(catalog.rankResults(directory, { title: 'Squid Game' })[0].title, 'Squid Game');
  assert.equal(catalog.episodeUrl(fixture('series'), series, 1, 1), episode);
  assert.equal(catalog.seasonUrl(fixture('series'), series, 2), base + '/dizi/breaking-bad/2-sezon-breaking-bad/');
  assert.deepEqual(catalog.pageIdentity(fixture('series')), { title: 'Breaking Bad', year: 2008 });
  const choices = catalog.playerChoices(fixture('episode'), episode);
  assert.equal(choices[0].kind, 'iframe');
  assert.ok(choices[0].url.indexOf(base + '/player/king/king.php?') === 0);
  assert.deepEqual(choices.slice(1), [
    { url: episode + '2/', kind: 'page', name: 'Moly+' },
    { url: episode + '3/', kind: 'page', name: 'Odnok' }
  ]);
});
